package Ejercicio4;

public class ContarNodoss {

    public static <T> int contarNodos(Node<T> head) {
        int contador = 0;
        Node<T> actual = head;

        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }

        return contador;
    }

    // Método principal de prueba
    public static void main(String[] args) {
        Node<Integer> lista = new Node<>(1);
        lista.siguiente = new Node<>(2);
        lista.siguiente.siguiente = new Node<>(3);

        int total = contarNodos(lista);
        System.out.println("Total de nodos: " + total); // Resultado: 3
    }
}


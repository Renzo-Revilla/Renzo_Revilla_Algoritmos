package Ejercicio2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InvertirLista {

    public static <T> List<T> invertirLista(List<T> listaOriginal) {
        List<T> listaInvertida = new ArrayList<>(listaOriginal);
        Collections.reverse(listaInvertida);
        return listaInvertida;
    }

    public static void main(String[] args) {
        List<String> nombres = List.of("Ana", "Luis", "Carlos");
        List<String> nombresInvertidos = invertirLista(nombres);
        System.out.println("Original: " + nombres);
        System.out.println("Invertida: " + nombresInvertidos);

        List<Integer> numeros = List.of(1, 2, 3, 4, 5);
        List<Integer> numerosInvertidos = invertirLista(numeros);
        System.out.println("Original: " + numeros);
        System.out.println("Invertida: " + numerosInvertidos);
    }
}

package Actividad;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        GestorDeTareas<Tarea> gestor = new GestorDeTareas<>();

        // 2. Agregar tareas
        gestor.agregarTarea(new Tarea("Estudiar", 2));
        gestor.agregarTarea(new Tarea("Ir al gym", 3));
        gestor.agregarTarea(new Tarea("Lavar ropa", 1));

        // 3. Eliminar una tarea
        gestor.eliminarTarea(new Tarea("Ir al gym", 3)); // solo compara por título

        // 4. Imprimir todas las tareas actuales
        System.out.println("Tareas actuales:");
        gestor.imprimirTareas();

        // 5. Verificar si existe una tarea
        System.out.println("¿Existe tarea 'Estudiar'? " + gestor.contieneTarea(new Tarea("Estudiar", 0)));

        // 6. Invertir la lista
        gestor.invertirTareas();
        System.out.println("Tareas invertidas:");
        gestor.imprimirTareas();

        // 7. Transferir tareas a una lista de tareas completadas
        List<Tarea> tareasCompletadas = gestor.obtenerLista();

        // 8. Mostrar ambas listas
        System.out.println("Lista de tareas completadas:");
        for (Tarea t : tareasCompletadas) {
            System.out.println(t);
        }

        System.out.println("Total de tareas: " + gestor.contarTareas());
        System.out.println("Tarea más prioritaria: " + gestor.obtenerTareaMasPrioritaria());
    }
}
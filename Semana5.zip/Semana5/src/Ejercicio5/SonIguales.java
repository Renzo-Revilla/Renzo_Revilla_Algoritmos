package Ejercicio5;

public class SonIguales {

    public static <T> boolean sonIguales(Node<T> lista1, Node<T> lista2) {
        while (lista1 != null && lista2 != null) {
            if (!lista1.dato.equals(lista2.dato)) {
                return false; // Los datos son diferentes
            }
            lista1 = lista1.siguiente;
            lista2 = lista2.siguiente;
        }

        // Si ambas listas terminaron al mismo tiempo, son iguales
        return lista1 == null && lista2 == null;
    }

    public static void main(String[] args) {
        Node<Integer> l1 = new Node<>(1);
        l1.siguiente = new Node<>(2);
        l1.siguiente.siguiente = new Node<>(3);

        Node<Integer> l2 = new Node<>(1);
        l2.siguiente = new Node<>(2);
        l2.siguiente.siguiente = new Node<>(3);

        Node<Integer> l3 = new Node<>(1);
        l3.siguiente = new Node<>(5);

        System.out.println("¿l1 y l2 son iguales? " + sonIguales(l1, l2)); // true
        System.out.println("¿l1 y l3 son iguales? " + sonIguales(l1, l3)); // false
    }
}

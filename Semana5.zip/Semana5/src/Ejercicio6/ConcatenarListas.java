package Ejercicio6;

public class ConcatenarListas {

    public static <T> Node<T> concatenarListas(Node<T> lista1, Node<T> lista2) {
        if (lista1 == null) return copiarLista(lista2);
        if (lista2 == null) return copiarLista(lista1);

        Node<T> nuevaLista = new Node<>(lista1.dato);
        Node<T> actualNueva = nuevaLista;
        Node<T> actual = lista1.siguiente;

        // Copiamos lista1
        while (actual != null) {
            actualNueva.siguiente = new Node<>(actual.dato);
            actualNueva = actualNueva.siguiente;
            actual = actual.siguiente;
        }

        // Copiamos lista2
        actual = lista2;
        while (actual != null) {
            actualNueva.siguiente = new Node<>(actual.dato);
            actualNueva = actualNueva.siguiente;
            actual = actual.siguiente;
        }

        return nuevaLista;
    }

    private static <T> Node<T> copiarLista(Node<T> original) {
        if (original == null) return null;

        Node<T> copia = new Node<>(original.dato);
        Node<T> actualCopia = copia;
        Node<T> actualOriginal = original.siguiente;

        while (actualOriginal != null) {
            actualCopia.siguiente = new Node<>(actualOriginal.dato);
            actualCopia = actualCopia.siguiente;
            actualOriginal = actualOriginal.siguiente;
        }

        return copia;
    }

    // Método para imprimir listas
    public static <T> void imprimirLista(Node<T> head) {
        Node<T> actual = head;
        while (actual != null) {
            System.out.print(actual.dato + " -> ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        Node<Integer> l1 = new Node<>(1);
        l1.siguiente = new Node<>(2);

        Node<Integer> l2 = new Node<>(3);
        l2.siguiente = new Node<>(4);

        Node<Integer> listaConcatenada = concatenarListas(l1, l2);
        System.out.print("Lista concatenada: ");
        imprimirLista(listaConcatenada);
    }
}

package Ejercicio1;

import java.util.List;

public class BusquedaGenerica {

    public static <T> boolean buscarElemento(List<T> lista, T valor) {
        for (T elemento : lista) {
            if (elemento.equals(valor)) {
                return true;
            }
        }
        return false;
    }

    // Ejemplo de uso
    public static void main(String[] args) {
        List<String> listaNombres = List.of("Ana", "Luis", "Carlos");
        boolean encontrado = buscarElemento(listaNombres, "Luis");
        System.out.println("¿Elemento encontrado? " + encontrado);  // Imprime: true

        List<Integer> listaNumeros = List.of(10, 20, 30);
        boolean existe = buscarElemento(listaNumeros, 25);
        System.out.println("¿Elemento encontrado? " + existe);  // Imprime: false
    }
}


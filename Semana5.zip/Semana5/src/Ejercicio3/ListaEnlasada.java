package Ejercicio3;

public class ListaEnlasada {

    public static <T> Node<T> insertarAlFinal(Node<T> head, T valor) {
        Node<T> nuevoNodo = new Node<>(valor);

        if (head == null) {
            return nuevoNodo;  // Si la lista está vacía, el nuevo nodo es la cabeza
        }

        Node<T> actual = head;
        while (actual.siguiente != null) {
            actual = actual.siguiente;
        }

        actual.siguiente = nuevoNodo;  // Agregamos el nuevo nodo al final
        return head;
    }

    // Método para imprimir la lista (para pruebas)
    public static <T> void imprimirLista(Node<T> head) {
        Node<T> actual = head;
        while (actual != null) {
            System.out.print(actual.dato + " -> ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        Node<Integer> lista = null;
        lista = insertarAlFinal(lista, 10);
        lista = insertarAlFinal(lista, 20);
        lista = insertarAlFinal(lista, 30);
        imprimirLista(lista);  // Resultado: 10 -> 20 -> 30 -> null
    }
}
